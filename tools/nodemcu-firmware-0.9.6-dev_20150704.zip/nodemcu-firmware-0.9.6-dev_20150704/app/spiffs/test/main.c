#include "testrunner.h"
#include <stdlib.h>

int main(int argc, char **args) {
  run_tests(argc, args);
  exit(EXIT_SUCCESS);
}
